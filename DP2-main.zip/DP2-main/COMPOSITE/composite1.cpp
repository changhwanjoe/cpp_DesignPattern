#include <cstdio>

int main()
{
	printf("1. 김밥\n");
	printf("2. 라면\n");
	printf("3. 종료\n");

	int cmd = 0;
	scanf_s("%d", &cmd);

	switch (cmd)
	{
	case 1: break;
	case 2: break;
	case 3: break;
	}
}