#include <iostream>
#include "Point.h"

int main()
{
	Point pt(1,2);
	pt.print();
}