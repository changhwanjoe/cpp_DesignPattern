class PointImpl
{
	int x, y;	
	int debug;
public:
	PointImpl(int x, int y);

	void print() const;
};